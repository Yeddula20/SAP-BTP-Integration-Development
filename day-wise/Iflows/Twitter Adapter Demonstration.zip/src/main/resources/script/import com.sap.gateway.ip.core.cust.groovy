import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import groovy.json.JsonOutput
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

def enc(String s) {
    URLEncoder.encode(s, "UTF-8").replace("+", "%20").replace("*", "%2A").replace("%7E", "~")
}

def secret(String alias) {
    def svc = ITApiFactory.getService(SecureStoreService.class, null)
    def cred = svc.getUserCredential(alias)
    if (cred == null) {
        throw new RuntimeException("Secure Parameter '" + alias + "' not found or not deployed")
    }
    return new String(cred.getPassword()).trim()
}

def Message processData(Message message) {

    def baseText = (message.getBody(String.class) ?: "Hello from SAP Integration Suite").trim()
    def text = baseText + " | " + new Date().format("dd-MMM-yyyy HH:mm:ss")

    def consumerKey    = secret("TW_CONSUMER_KEY")
    def consumerSecret = secret("TW_CONSUMER_SECRET")
    def token          = secret("TW_ACCESS_TOKEN")
    def tokenSecret    = secret("TW_ACCESS_SECRET")

    // PUT YOUR WEBHOOK URL HERE (must match the HTTP channel address exactly)
    def url = "https://webhook.site/PASTE-YOUR-ID-HERE"

    def oauth = [
        oauth_consumer_key    : consumerKey,
        oauth_nonce           : UUID.randomUUID().toString().replace("-", ""),
        oauth_signature_method: "HMAC-SHA1",
        oauth_timestamp       : (System.currentTimeMillis() / 1000).toLong().toString(),
        oauth_token           : token,
        oauth_version         : "1.0"
    ]

    def paramString = oauth.sort().collect { k, v -> enc(k) + "=" + enc(v) }.join("&")
    def baseString  = "POST&" + enc(url) + "&" + enc(paramString)
    def signingKey  = enc(consumerSecret) + "&" + enc(tokenSecret)

    def mac = Mac.getInstance("HmacSHA1")
    mac.init(new SecretKeySpec(signingKey.getBytes("UTF-8"), "HmacSHA1"))
    oauth.oauth_signature = mac.doFinal(baseString.getBytes("UTF-8")).encodeBase64().toString()

    def authHeader = "OAuth " + oauth.collect { k, v -> enc(k) + "=\"" + enc(v) + "\"" }.join(", ")

    message.setHeader("Authorization", authHeader)
    message.setHeader("Content-Type", "application/json")
    message.setBody(JsonOutput.toJson([text: text]))
    return message
}