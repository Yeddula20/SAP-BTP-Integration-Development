import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import groovy.json.JsonOutput
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

def enc(String s) {
    URLEncoder.encode(s, "UTF-8").replace("+", "%20").replace("*", "%2A").replace("%7E", "~")
}

def secret(String alias) {
    def svc = ITApiFactory.getService(SecureStoreService.class, null)
    return new String(svc.getUserCredential(alias).getPassword())
}

def Message processData(Message message) {
    def text = message.getBody(String.class)

    def consumerKey    = secret("TW_CONSUMER_KEY")
    def consumerSecret = secret("TW_CONSUMER_SECRET")
    def token          = secret("TW_ACCESS_TOKEN")
    def tokenSecret    = secret("TW_ACCESS_SECRET")

    def url = "https://api.x.com/2/tweets"
    def oauth = [
        oauth_consumer_key    : consumerKey,
        oauth_nonce           : UUID.randomUUID().toString().replace("-", ""),
        oauth_signature_method: "HMAC-SHA1",
        oauth_timestamp       : (System.currentTimeMillis() / 1000).toLong().toString(),
        oauth_token           : token,
        oauth_version         : "1.0"
    ]

    // Signature base string (JSON body is NOT part of the signature)
    def paramString = oauth.sort().collect { k, v -> "${enc(k)}=${enc(v)}" }.join("&")
    def baseString  = "POST&${enc(url)}&${enc(paramString)}"
    def signingKey  = "${enc(consumerSecret)}&${enc(tokenSecret)}"

    def mac = Mac.getInstance("HmacSHA1")
    mac.init(new SecretKeySpec(signingKey.getBytes("UTF-8"), "HmacSHA1"))
    def signature = mac.doFinal(baseString.getBytes("UTF-8")).encodeBase64().toString()
    oauth.oauth_signature = signature

    def header = "OAuth " + oauth.collect { k, v -> "${enc(k)}=\"${enc(v)}\"" }.join(", ")

    message.setHeader("Authorization", header)
    message.setHeader("Content-Type", "application/json")
    message.setBody(JsonOutput.toJson([text: text]))
    return message
}