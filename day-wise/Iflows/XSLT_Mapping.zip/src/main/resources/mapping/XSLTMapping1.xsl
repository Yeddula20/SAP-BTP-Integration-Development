<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs" version="1.0">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes"/>
<xsl:template match="/">
<xsl:variable name="Lines" select="//Line///Material"/>
<input>
<xsl:copy-of select="//Header"/>
<xsl:for-each select="$Lines">
<item>
<MatNo>
<xsl:value-of select="MatType"/>
</MatNo>
<NetPrice>
<xsl:value-of select="Price"/>
</NetPrice>
</item>
</xsl:for-each>
</input>
</xsl:template>
</xsl:stylesheet>
